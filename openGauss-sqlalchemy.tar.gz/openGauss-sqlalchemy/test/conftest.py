# -*- coding: utf-8 -*-
from sqlalchemy.testing.plugin.pytestplugin import *  # noqa

import opengauss_sqlalchemy  # noqa
